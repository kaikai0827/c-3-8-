#include <iostream>
#include <string>

class Student
{
public:
    void get_value()
    {
        std::cin >> num >> name >> sex;
    }

    void display()
    {
        std::cout << "num:" << num << std::endl;
        std::cout << "name:" << name << std::endl;
        std::cout << "sex:" << sex << std::endl;
    }

protected://改之前private 不可访问
    int num;
    std::string name;
    char sex;
};

class Student1 : private Student
{
public:
    void get_value_1()
    {
        get_value();
        std::cin >> age >> addr;
    }

    void display_1()
    {

        std::cout << "num:" << num << std::endl;
        std::cout << "name:" << name << std::endl;
        std::cout << "sex:" << sex << std::endl;
        std::cout << "age:" << age << std::endl;
        std::cout << "addr:" << addr << std::endl;
    }

private:
    int age;
    std::string addr;
};

int main()
{
    Student1 stud;
    
    stud.get_value_1();
    stud.display_1();

    return 0;
}