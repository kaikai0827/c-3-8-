#include <iostream>
#include <string>

class Teacher
{
public:
    Teacher(int num, std::string name, char sex) : num(num), name(name), sex(sex) {}
    int getNum() const { return num; }
    std::string getName() const { return name; }
    char getSex() const { return sex; }

private:
    int num;
    std::string name;
    char sex;
};

class BirthDate
{
public:
    BirthDate(int year, int month, int day) : year(year), month(month), day(day) {}
    int getYear() const { return year; }
    int getMonth() const { return month; }
    int getDay() const { return day; }
    void setYear(int year) { this->year = year; }
    void setMonth(int month) { this->month = month; }
    void setDay(int day) { this->day = day; }

private:
    int year;
    int month;
    int day;
};

class Professor : public Teacher
{
public:
    Professor(int num, std::string name, char sex, int year, int month, int day)
        : Teacher(num, name, sex), birthday(year, month, day) {}

    BirthDate getBirthday() const
    {
        return this->birthday;
    }
    void setBirthday(const BirthDate &birthday)
    {
        this->birthday = birthday;
    }

private:
    BirthDate birthday;
};

void fun1(const Teacher &teacher)
{
    std::cout << "Teacher information: \n";
    std::cout << "Number: " << teacher.getNum() << std::endl;
    std::cout << "Name: " << teacher.getName() << std::endl;
    std::cout << "Sex: " << teacher.getSex() << std::endl;
}

void fun2(Professor& professor)
{
    std::cout << "Please enter birth year, month and day: ";
    int year, month, day;
    std::cin >> year >> month >> day;
    professor.getBirthday().setYear(year);
    professor.getBirthday().setMonth(month);
    professor.getBirthday().setDay(day);
}

int main()
{
    Professor profl(1001, "Tom", 'M', 1980, 1, 1);
    std::cout << "Original information: \n";
    fun1(profl);
    std::cout << "Birth year: " << profl.getBirthday().getYear() << std::endl;
    std::cout << "Birth month: " << profl.getBirthday().getMonth() << std::endl;
    std::cout << "Birth day: " << profl.getBirthday().getDay() << std::endl;
    profl.setBirthday(BirthDate(0, 0, 0));

    fun2(profl);
    std::cout << "Newest information: \n";
    fun1(profl);
    std::cout << "Birth year: " << profl.getBirthday().getYear() << std::endl;
    std::cout << "Birth month: " << profl.getBirthday().getMonth() << std::endl;
    std::cout << "Birth day: " << profl.getBirthday().getDay() << std::endl;

    return 0;
}