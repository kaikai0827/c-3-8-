#include "Cylinder.h"

Cylinder::Cylinder(float x = 0, float y = 0, float r = 0, float h = 0)
    : Circle(x, y, r), height(h)
{
}
void Cylinder::setHeight(float h)
{
    height=h;
}
float Cylinder::getHeight() const
{
    return height;
}
float Cylinder::area() const
{
    return 2*Circle::area()+3.14159*height*2*getRadius();
}
float Cylinder::volume() const
{
    return Circle::area()*height;
}

std::ostream &operator<<(std::ostream &os, const Cylinder &cylinder)
{
    os<<"x="<<cylinder.x<<" "<<"y="<<cylinder.y<<" "<<"height="<<cylinder.height<<" "<<"radius="<<cylinder.getRadius()<<" "<<
    "volume="<<cylinder.volume();
    return os;
}
