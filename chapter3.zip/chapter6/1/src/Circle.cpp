#include "Circle.h"

Circle::Circle(float x = 0, float y = 0, float r = 0)
    : Point(x, y), radius(r)
{
}

void Circle::setRadius(float r)
{
    radius = r;
}

float Circle::getRadius() const
{
    return radius;
}

float Circle::area() const
{
    return 3.14159 * radius * radius;
}

std::ostream &operator<<(std::ostream &os, const Circle &circle)
{
    os << circle.x << " " << circle.y << "   " << circle.area();
    return os;
}
