#pragma once
#include <iostream>

class Point
{
public:
    Point(float, float);
    void setPoint(float, float);
    float getX() const;
    float getY() const;
    friend std::ostream &operator<<(std::ostream &os, const Point &point);

protected:
    float x;
    float y;
};