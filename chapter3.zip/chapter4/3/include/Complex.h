#include <iostream>
#include <exception>
class Complex
{
public:
    Complex(double a = 0, double b = 0)
        : a_(a), b_(b)
    {
    }
    Complex(double a)
        : a_(a), b_(0)
    {
    }

    Complex operator+(const Complex &rhs) const
    {
        return Complex(a_ + rhs.a_, b_ + rhs.b_);
    }
    friend Complex operator+(double lhs, const Complex &rhs);

    Complex operator-(const Complex &rhs) const
    {
        return Complex(a_ - rhs.a_, b_ - rhs.b_);
    }

    Complex operator*(const Complex &rhs) const
    {
        return Complex(a_ * rhs.a_ - b_ * rhs.b_, a_ * rhs.b_ + b_ * rhs.a_);
    }

    Complex operator/(const Complex &rhs) const
    {
        if (rhs.a_ == 0 && rhs.b_ == 0)
        {
            std::cerr << "Invalid!" << std::endl;
            throw std::domain_error("Division by zero");
        }

        int denom = rhs.a_ * rhs.a_ + rhs.b_ * rhs.b_;
        return Complex((a_ * rhs.a_ + b_ * rhs.b_) / (double)denom, (-a_ * rhs.b_ + b_ * rhs.a_) / (double)denom);
    }
    // 加了一个分母是不是0的检测 如果是就抛exception类的错

    friend std::ostream &operator<<(std::ostream &os, const Complex &rhs);

private:
    double a_;
    double b_;
};

Complex operator+(double lhs, const Complex &rhs)
{
    return Complex(lhs + rhs.a_, rhs.b_);
}

std::ostream &operator<<(std::ostream &os, const Complex &rhs)
{
    if (rhs.a_ != 0)
    {
        os << rhs.a_;
    }
    if (rhs.b_ != 0)
    {
        os << ((rhs.b_ > 0) ? '+' : '-') << abs(rhs.b_) << 'i';
    }
    return os;
}