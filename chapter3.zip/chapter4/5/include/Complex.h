#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>

class Rect
{
private:
    std::vector<std::vector<int>> rect;

public:
    Rect() {}

    Rect(const std::vector<std::vector<int>>& rhs)
        : rect(rhs)
    {
    }

    Rect(const Rect &rhs)
        : rect(rhs.rect)
    {
    }

    Rect(Rect &&rhs)
        : rect(std::move(rhs.rect))
    {
    }

    Rect& operator=(const Rect &rhs)
    {
        if (this == &rhs)
            return *this;

        rect = rhs.rect;
        return *this;
    }

    Rect operator+(const Rect &rhs) const
    {
        std::vector<std::vector<int>> rect1;

        for (int i = 0; i < rect.size(); i++)
        {
            std::vector<int> row;

            for (int j = 0; j < rect[i].size(); j++)
            {
                row.push_back(rect[i][j] + rhs.rect[i][j]);
            }

            rect1.push_back(row);
        }

        return Rect(rect1);
    }

    friend std::ostream& operator<<(std::ostream& os, const Rect& rect)
    {
        for (int i = 0; i < rect.rect.size(); i++)
        {
            for (int j = 0; j < rect.rect[i].size(); j++)
            {
                os << rect.rect[i][j] << " ";
            }

            os << std::endl;
        }

        return os;
    }

    friend std::istream& operator>>(std::istream& is, Rect& rect)
    {
        std::vector<std::vector<int>> rect1;

        while (is)
        {
            std::string line;
            std::getline(is, line);

            if (line.empty())
                break;

            std::stringstream ss(line);
            std::vector<int> row;

            while (ss)
            {
                int value;
                ss >> value;

                if (ss)
                    row.push_back(value);
            }

            if (!row.empty())
                rect1.push_back(row);
        }

        rect = Rect(rect1);

        return is;
    }
};