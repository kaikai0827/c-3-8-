#include <iostream>
#include "Complex.h"

int main()
{
    Complex Complex1(1, 1);
    Complex Complex2(2, 3);
    std::cout << Complex1 + Complex2 << std::endl;
    return 0;
}