#include <iostream>

class Complex
{
public:
    Complex(double a, double b)
        : a_(a), b_(b)
    {
    }

    Complex operator+(const Complex &rhs) const
    {
        return Complex(a_ + rhs.a_, b_ + rhs.b_);
    }

    Complex operator-(const Complex &rhs) const
    {
        return Complex(a_ - rhs.a_, b_ - rhs.b_);
    }

    Complex operator*(const Complex &rhs) const
    {
        return Complex(a_ * rhs.a_ - b_ * rhs.b_, a_ * rhs.b_ + b_ * rhs.a_);
    }

    Complex operator/(const Complex &rhs) const
    {
        int denom = rhs.a_ * rhs.a_ + rhs.b_ * rhs.b_;
        return Complex((a_ * rhs.a_ + b_ * rhs.b_) / (double)denom, (-a_ * rhs.b_ + b_ * rhs.a_) / (double)denom);
    }

    operator double() const
    {
        return a_;
    }
    //其实已经是double了 当练习了
    friend std::ostream &operator<<(std::ostream &os, const Complex &rhs);

private:
    double a_;
    double b_;
};

std::ostream &operator<<(std::ostream &os, const Complex &rhs)
{
    if (rhs.a_ != 0)
    {
        os << rhs.a_;
    }
    if (rhs.b_ != 0)
    {
        os << ((rhs.b_ > 0) ? '+' : '-') << abs(rhs.b_) << 'i';
    }
    return os;
}