#include <string>
#include <iostream>

class Student
{
public:
    Student(int n, float s);
    void change(int n,float s);
    void display();
    
private:
    int num;
    float score;
};