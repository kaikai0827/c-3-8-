#include <iostream>
#include "student.h"

void Student::insert()
{
    std::cin >> id_ >> grades_;
}

void Student::Print()
{
    std::cout << id_ << std::endl;
    std::cout << grades_ << std::endl;
}
