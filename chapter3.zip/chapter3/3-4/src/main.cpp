#include "student.h"
#include <vector>

int main()
{
    Student arr[5];
    for (int i = 0; i < 5; i++)
    {
        arr[i].insert();
    }
    Student *p;
    p = arr;
    for (int i = 0; i < 5; i += 2)
    {
        p->Print();
        p += 2;
    }
    return 0;
}