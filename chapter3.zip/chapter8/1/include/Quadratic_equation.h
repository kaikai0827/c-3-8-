#include <iostream>
#include <math.h>

class Quadratic_equation
{
private:
    double a_;
    double b_;
    double c_;

    double x1;
    double x2;

public:
    Quadratic_equation(int a, int b = 0, int c = 0)
        : a_(a), b_(b), c_(c)
    {
        if (a == 0)
        {
            std::cerr << "Invalid!" << std::endl;
        }
    }

    void Check()
    {
        double delta = b_ * b_ - 4 * a_ * c_;
        if (delta < 0)
        {
            std::cerr << "The Quadratic_equation has no real root!" << std::endl;
        }
        else if (delta == 0)
        {
            std::cout << "The Quadratic_equation has one real root!" << std::endl;
            x1 = x2 = -b_ / (2 * a_);
            std::cout << "x1=x2=" << x1 << std::endl;
        }
        else
        {
            std::cout << "The Quadratic_equation has two real root!" << std::endl;
            x1 = (-b_ + sqrt(delta)) / (2 * a_);
            x2 = (-b_ - sqrt(delta)) / (2 * a_);
            std::cout<<"x1="<<x1<<" "<<"x2="<<x2<<std::endl;
        }
    }
};