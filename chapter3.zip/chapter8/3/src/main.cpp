#include<iostream>
#include<string>
using namespace std;

namespace HRDept {
    struct Student {
        int num;
        string name;
        int age;
        string address;
    };
    void print_info(const Student& stu) {
        cout << "num: " << stu.num << endl;
        cout << "name: " << stu.name << endl;
        cout << "age: " << stu.age << endl;
        cout << "address: " << stu.address << endl << endl;
    }
}

namespace EduDept {
    struct Student {
        int num;
        string name;
        int gender;
        int grade;
    };
    void print_info(const Student& stu) {
        cout << "num: " << stu.num << endl;
        cout << "name: " << stu.name << endl;
        cout << "gender: " << (stu.gender == 0 ? "male" : "female") << endl;
        cout << "grade: " << stu.grade << endl << endl;
    }
}

namespace AllStudents {
    using HRStudent = HRDept::Student;
    using EduStudent = EduDept::Student;
    void print_info(const HRStudent& hr_stu, const EduStudent& edu_stu) {
        cout << "<Info from HR Dept>" << endl;
        HRDept::print_info(hr_stu);
        cout << "<Info from Edu Dept>" << endl;
        EduDept::print_info(edu_stu);
    }
}

int main() {
    HRDept::Student hr_stu {1001, "Tom", 22, "Shanghai"};
    EduDept::Student edu_stu {1001, "Tom", 0, 95};
    AllStudents::print_info(hr_stu, edu_stu);
    return 0;
}