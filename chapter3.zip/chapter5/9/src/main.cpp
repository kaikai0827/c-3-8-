#include<iostream>
#include<string>
using namespace std;

class Teacher {
public:
    string name;
    int age;
    char gender;
    string address;
    string phone;
    string title;

    void display();
};

void Teacher::display()
{
    cout << "name:" << name << endl;
    cout << "age:" << age << endl;
    cout << "gender:" << gender << endl;
    cout << "address:" << address << endl;
    cout << "phone:" << phone << endl;
    cout << "title:" << title << endl;
}

class Cadre {
protected:
    string name;
    int age;
    char gender;
    string address;
    string phone;
    string post;
public:
    void display();
};

void Cadre::display()
{
    cout << "name:" << name << endl;
    cout << "age:" << age << endl;
    cout << "gender:" << gender << endl;
    cout << "address:" << address << endl;
    cout << "phone:" << phone << endl;
    cout << "post:" << post << endl;
}

class Teacher_Cadre : public Teacher, public Cadre {
protected:
    int wages;
public:
    void show();
};

void Teacher_Cadre::show()
{
    Teacher::display();
    cout << "post:" << Cadre::post << endl;
    cout << "wages:" << wages << endl;
}

int main()
{
    Teacher_Cadre tc;
    tc.Teacher::name = "zhangsan";
    tc.Teacher::age = 30;
    tc.Teacher::gender = '1';
    tc.Teacher::address = "beijing";
    tc.Teacher::phone = "123456789";
    tc.Teacher::title = "advanced Teacher";
    tc.show();

    return 0;
}