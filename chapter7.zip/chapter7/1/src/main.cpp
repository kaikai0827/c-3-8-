#include <iostream>

int main()
{
    double a, b, c;
    std::cin >> a >> b >> c;
    if (a + b > c && a + c > b && b + c > a)
    {
        std::cout << "Valid!" << std::endl;
    }
    else
    {
        std::cerr << "Invalid!" << std::endl;
        exit(-1);
    }
    return 0;
}