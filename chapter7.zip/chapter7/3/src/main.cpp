#include <iostream>
#include <iomanip>

int main()
{
    int n;
    std::cin>>n;
    for(int i=n-1;i>=0;i--)
    {
        for(int j=i;j>0;j--)
        {
            std::cout<<" ";
        }
        for(int k=1;k<=1+(n-i-1)*2;k++)
        {
            std::cout<<'B';
        }
        std::cout<<std::endl;
    }
    return 0;
}