#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int nums[20];  // 存放20个整数
    // 从键盘输入20个整数
    for (int i = 0; i < 20; i++) {
        cout << "请输入一个整数：";
        cin >> nums[i];
    }

    // 将20个整数分别存放到两个文件中
    ofstream f1("f1.dat", ios::binary);  // 打开二进制文件
    for (int i = 0; i < 10; i++) {
        int num = nums[i];
        f1.write(reinterpret_cast<const char*>(&num), sizeof(int));
    }
    f1.close();  // 关闭文件

    ofstream f2("f2.dat", ios::binary);
    for (int i = 10; i < 20; i++) {
        int num = nums[i];
        f2.write(reinterpret_cast<const char*>(&num), sizeof(int));
    }
    f2.close();

    // 以f1.dat读取10个数，然后存放到f2.dat文件原有数据的后面
    ifstream f1_read("f1.dat", ios::binary);
    f1_read.seekg(0, ios::beg);  // 移动文件指针到开始位置
    ofstream f2_append("f2.dat", ios::binary | ios::app);
    for (int i = 0; i < 10; i++) {
        int num;
        f1_read.read(reinterpret_cast<char*>(&num), sizeof(int));
        f2_append.write(reinterpret_cast<const char*>(&num), sizeof(int));
    }
    f1_read.close();
    f2_append.close();

    // 从f2.dat中读取20个整数并对它们按从小到大的顺序存放到f2.dat（不保留原来的数据）
    ifstream f2_read("f2.dat", ios::binary);
    vector<int> nums2;
    for (int i = 0; i < 20; i++) {
        int num;
        f2_read.read(reinterpret_cast<char*>(&num), sizeof(int));
        nums2.push_back(num);
    }
    f2_read.close();
    sort(nums2.begin(), nums2.end());

    ofstream f2_write("f2.dat", ios::binary);  // 打开文件进行写入操作
    for (int i = 0; i < 20; i++) {
        int num = nums2[i];
        f2_write.write(reinterpret_cast<const char*>(&num), sizeof(int));
    }
    f2_write.close();

    return 0;
}