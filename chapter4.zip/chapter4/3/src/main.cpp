#include <iostream>
#include "Complex.h"

int main()
{
    Complex Complex1(1, 1);
    Complex Complex2(2, 3);
    std::cout << 1+Complex1<< std::endl;
    return 0;
}