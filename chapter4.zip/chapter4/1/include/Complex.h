#include <iostream>

class Complex
{
public:
    Complex(int a, int b)
        : a_(a), b_(b)
    {
    }

private:
    int a_;
    int b_;
};

const Complex &operator+(const Complex &rhs)
{
    return Complex(Complex::a_ + rhs.a_, b_ + rhs.b_);
}
