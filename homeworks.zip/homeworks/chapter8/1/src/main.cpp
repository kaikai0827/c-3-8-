#include <iostream>
#include<Quadratic_equation.h>

int main()
{
    Quadratic_equation q(1,-4,4);
    q.Check();
    return 0;
}