#include <string>
#include <iostream>

class Student
{
private:
    std::string id_;
    int grades_;

public:
    void insert();
    void Print();
};