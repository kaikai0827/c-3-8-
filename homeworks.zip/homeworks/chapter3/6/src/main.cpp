#include "student.h"

int main()
{
    Student stud(101,78.5);
    stud.display();
    stud.change(101,80.5);
    stud.display();
    return 0;
}