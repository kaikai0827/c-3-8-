#include <iostream>
#include "student.h"

Student::Student(int n, float s)
    : num(n), score(s)
{
}

void Student::change(int n, float s)
{
    num = n;
    score = s;
}

void Student::display()
{
    std::cout << num << " " << score << std::endl;
}
