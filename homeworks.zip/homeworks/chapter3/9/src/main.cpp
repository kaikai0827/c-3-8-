#include <iostream>

class Sales
{
public:
    Sales(int n, double q, double p)
        : num(n), quantity(q), price(p) {}

    static void set_discount(double d) { discount = d; }
    static void add_sales(double sum, int count) { total_sum += sum; total_count += count; }
    static double average() { return total_sum / total_count; }
    static void display() { std::cout << "Total sales: " << total_sum << std::endl; std::cout << "Average price: " << average() << std::endl; }

    int num;
    double quantity;
    double price;

    static double discount;
    static double total_sum;
    static int total_count;
};

double Sales::discount = 0;
double Sales::total_sum = 0;
int Sales::total_count = 0;

int main()
{
    Sales s1(101, 5, 23.5);
    Sales s2(102, 12, 24.56);
    Sales s3(103, 100, 21.5);

    Sales::set_discount(0.02);

    double sum = s1.quantity * s1.price + s2.quantity * s2.price + s3.quantity * s3.price;
    if (s1.quantity >= 10) sum *= (1 - Sales::discount);
    if (s2.quantity >= 10) sum *= (1 - Sales::discount);
    if (s3.quantity >= 10) sum *= (1 - Sales::discount);

    Sales::add_sales(sum, s1.quantity + s2.quantity + s3.quantity);

    Sales::display();

    return 0;
}