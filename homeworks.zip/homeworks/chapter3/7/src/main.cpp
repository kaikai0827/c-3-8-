#include "student.h"

// int main()
// {
//     Student stud(101,78.5);
//     stud.display();
//     stud.change(101,80.5);
//     stud.display();
//     return 0;
// }

int main()
{
    Student stud(101,78.5);
    
    Student* const p=&stud;
    p->display();
    p->change(101,80.5);
    p->display();

    return 0;
}