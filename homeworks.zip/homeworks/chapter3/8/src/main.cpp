#include "student.h"

void fun(Student& s)
{
    s.change(101,78.5);
    s.display();
}

int main()
{
    Student stud(101,78.5);
    fun(stud);
    return 0;
}