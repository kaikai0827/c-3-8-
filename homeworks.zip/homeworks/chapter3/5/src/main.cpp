#include "student.h"
#include <vector>

int Max(Student* arr)
{
    int max=arr[0].getGrades();
    for(int i=0;i<5;i++)
    {
        if(max<arr[i].getGrades())
        {
            max=arr[i].getGrades();
        }
    }
    return max;
}

int main()
{
    Student arr[5];
    for (int i = 0; i < 5; i++)
    {
        arr[i].insert();
    }
    std::cout<<Max(arr)<<std::endl;
    return 0;
}