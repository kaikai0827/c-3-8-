#include <iostream>

class Date;

class Time
{
public:
    Time(int h = 0, int m = 0, int s = 0)
        : hour(h), minute(m), sec(s) {}
    void display(Date &);

private:
    int hour;
    int minute;
    int sec;
};

class Date
{
public:
    Date(int m = 1, int d = 1, int y = 2005)
        : month(m), day(d), year(y) {}
    
    friend void Time::display(Date &);

private:
    int month;
    int day;
    int year;

};



void Time::display(Date &d)
{
    std::cout << d.month << "/" << d.day << "/" << d.year << std::endl;
    std::cout << hour << ":" << minute << ":" << sec << std::endl;
}
int main()
{
    Time t1(10, 13, 56);
    Date d1(12, 25, 2004);
    t1.display(d1);
    return 0;
}