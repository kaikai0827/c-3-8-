#include <iostream>
#include <string>

class Student
{
public:
protected: // 改之前private 不可访问
    int num;
    std::string name;
    char sex;
};

class Student1 : protected Student
{
public:
    void get_value_1();
    void display_1();

private:
    int age;
    std::string addr;
};

void Student1::get_value_1()
{
    std::cin >> num >> name >> sex;
    std::cin >> age >> addr;
}

void Student1::display_1()
{

    std::cout << "num: " << num << std::endl;
    std::cout << "name: " << name << std::endl;
    std::cout << "sex: " << sex << std::endl;
    std::cout << "age: " << age << std::endl;
    std::cout << "address: " << addr << std::endl;
}

int main()
{
    Student1 stud;

    stud.get_value_1();
    stud.display_1();

    return 0;
}