#include <iostream>
#include "Cylinder.h"
int main()
{
    Cylinder c(1, 2, 3, 4);
    c.setHeight(5);
    std::cout << c.area() << std::endl;   // 输出 150.796（2*3.14159*3*3+3.14159*5*2*3）
    std::cout << c.volume() << std::endl; // 输出 141.372（3.14159*3*3*5）
    std::cout << c << std::endl;          // 输出 x=1 y=2 height=5 radius=3 volume=56.5487

    Cylinder c2(6, 5, 0, 0);
    c2.setRadius(1);
    c2.setHeight(2);
    std::cout << c2.area() << std::endl;   // 输出 18.8495（2*3.14159*1*1+3.14159*2*2*1）
    std::cout << c2.volume() << std::endl; // 输出 6.28319（3.14159*1*1*2）
    std::cout << c2 << std::endl;
    return 0;
}