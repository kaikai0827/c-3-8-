#include "Point.h"

Point::Point(float x = 0, float y = 0)
    : x(x), y(y)
{
}
void Point::setPoint(float a, float b)
{
    x = a;
    y = b;
}
float Point::getX() const
{
    return x;
}
float Point::getY() const
{
    return y;
}

std::ostream &operator<<(std::ostream &os, const Point &point)
{
    os << point.x << " " << point.y;
    return os;
}
