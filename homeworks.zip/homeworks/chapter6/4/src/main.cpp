#include <iostream>
#include <string>

class Sharp
{
public:
    Sharp(double length)
        : length(length)
    {
    }
    virtual void printArea() = 0;
    
protected:
    double length;
};

class Circle : public Sharp
{
public:
    Circle(double length)
        : Sharp(length)
    {
    }

    virtual void printArea()
    {
        std::cout<<"Area="<<3.14159*length*length<<std::endl;
    }
};