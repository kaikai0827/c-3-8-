#include <iostream>
#include <vector>
#include <algorithm>

class Rect
{
private:
    std::vector<std::vector<int>> rect;

public:
    Rect(const std::vector<std::vector<int>>& rhs)
        : rect(rhs)
    {
    }

    Rect(const Rect &rhs)
        : rect(rhs.rect)
    {
    }

    Rect(Rect &&rhs)
        : rect(std::move(rhs.rect))
    {
    }

    Rect operator+(const Rect &rhs) const
    {
        std::vector<std::vector<int>> rect1;

        for (int i = 0; i < rect.size(); i++)
        {
            for (int j = 0; j < rect[i].size(); j++)
            {
                rect1[i][j] = rect[i][j] + rhs.rect[i][j];
            }
        }
        return rect1;
    }
};