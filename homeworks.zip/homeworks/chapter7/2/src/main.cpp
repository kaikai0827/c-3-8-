#include <iostream>
#include <iomanip>

int main()
{
    double num;
    while (std::cin >> num)
    {
        std::cout << std::fixed << std::setprecision(3) << std::setw(15) << std::setfill(' ') << num << std::endl;
    }
    return 0;
}