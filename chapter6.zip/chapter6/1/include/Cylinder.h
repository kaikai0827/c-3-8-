#pragma once
#include "Circle.h"

class Cylinder : public Circle
{
public:
    Cylinder(float, float, float, float);
    void setHeight(float);
    float getHeight() const;
    float area() const;
    float volume() const;

    friend std::ostream &operator<<(std::ostream &os, const Cylinder& cylinder);

protected:
    float height;
};