#pragma once
#include "Point.h"

class Circle : public Point
{
public:
    Circle(float, float, float);
    void setRadius(float);
    float getRadius() const;
    float area() const;
    friend std::ostream &operator<<(std::ostream &os, const Circle &circle);

private:
    float radius;
};